/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paspacalc;

import java.util.Scanner;

public class PaspaCalc {

    public static float addition(float x, float y) {
        return x + y;
    }

    public static float subtraction(float x, float y) {
        return x - y;
    }

    public static float multiplication(float x, float y) {
        return x * y;
    }

    public static float division(float x, float y) {
        float solution = x / y;
        return solution;
    }

    public static void calculator() {
        Scanner xInput = new Scanner(System.in);
        Scanner yInput = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        float x;
        float y;
        int ops;
        System.out.println("Wanna Do math?? ('+', '-', '*', '/')");
        System.out.println(" Enter 1 for Addition");
        System.out.println(" Enter 2 for Subtraction");
        System.out.println(" Enter 3 for Multiplication");
        System.out.println(" Enter 4 for Division");
        ops = sc.nextInt();
        switch (ops) {
            case (1):
                System.out.println("Give first number:");
                x = xInput.nextFloat();
                System.out.println("Give second number");
                y = yInput.nextFloat();
                System.out.println(addition(x, y));

                break;
            case (2):
                System.out.println("Give first number:");
                x = xInput.nextFloat();
                System.out.println("Give second number");
                y = yInput.nextFloat();
                System.out.println(subtraction(x, y));

                break;
            case (3):
                System.out.println("Give first number:");
                x = xInput.nextFloat();
                System.out.println("Give second number:");
                y = yInput.nextFloat();
                System.out.println(multiplication(x, y));

                break;
            case (4):
                System.out.println("Give first number:");
                x = xInput.nextFloat();
                System.out.println("Give second number");
                y = yInput.nextFloat();
                System.out.println(division(x, y));

                break;
            default:
                System.out.println("Invalid input");

        }

    }

    public static void main(String[] args) {

        calculator();

    }

}
